---AIRPLANE SPRITE README---

The only conditions I'd like to apply to their use are these:
1. Notify me if you use them, because I like seeing stuff I draw put to use.
2. Give me a little credit, include my name in there somewhere(see bottom)

----CONTAINS----

3 Folders
Top View- Contains high resolution top views of different aircraft, mostly fighters.
Side View- Contains, um, side views of various scales.
Multiple Views- Contains some animated frames as well as designs from multiple angles.(contains many top and side views that are not in other folders)


----INFO----

All art is original, drawn by me, Prinz Eugn, aka Mark Simpson. Artwork ranges from a few years old to very recent, and quality varies. 
Aircraft contained are both original and real-world designs, and are named using their technical designations(which are made up for original designs).
If you have questions on anything, feel free to contact me. You are welcome to submit simple requests, but I am usually busy, so I can't promise anything :/
Contact information:
Email: 
prinz_eugn@hotmail.com -Preffered contact

Web Sites:
http://prinzeugn.deviantart.com/ -updated frequently
http://www.gamedev.net/community/forums/mod/journal/journal.asp?userid=85721 -Updated less frequently, bus has information on my current projects
----

All art copyright Mark Simpson 2001-2008(c)